export default {
    modal: {
        top: '35%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        width: '60%',
        transform: 'translate(-40%, -10%)'
    },
    greenText: {
        color: 'rgb(0,255,100)'
    },
    style3: {
        marginRight: '-25%'
    }
}
